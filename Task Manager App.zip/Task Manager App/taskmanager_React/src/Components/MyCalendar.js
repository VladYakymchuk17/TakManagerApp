import React, { useState, useEffect, useMemo } from 'react';
import Sidebar from './Sidebar';
import { useLocation } from 'react-router-dom';
import '../Styles/MyCalendar.css';
import LoadingCircle from './LoadingCircle';
import axios from 'axios';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

const MyCalendar = () => {
    const location = useLocation();
    const id = useMemo(() => location.state || {}, [location.state]);
    const [userEvents, setEvents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [selectedDate, setSelectedDate] = useState(new Date());

    useEffect(() => {
        const fetchEvents = async () => {
            const firstDayOfMonth = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), 1);
            const lastDayOfMonth = new Date(selectedDate.getFullYear(), selectedDate.getMonth() + 1, 0);

            const requestObject = {
                startDateTime: firstDayOfMonth.toISOString(),
                endDateTime: lastDayOfMonth.toISOString(),
                userId: id
            };
            console.log(requestObject);

            await axios.post('https://localhost:7034/api/Events/ByMonth', requestObject).then(res => {
                setEvents(res.data);
                console.log(res.data);
                setLoading(false);
            }).catch(error => {
                setLoading(false);
                setError(error);
                if (error.response) {
                    console.error('Error response:', error.response.data);
                    window.alert(`Error: ${error.response.data}`);
                } else if (error.request) {
                    console.error('Error request:', error.request);
                    window.alert('Error: No response received from the server.');
                } else {
                    console.error('Error message:', error.message);
                    window.alert(`Error: ${error.message}`);
                }
            });
        };

        fetchEvents();
    }, [selectedDate, id]);

    const handleDateChange = (date) => {
        setSelectedDate(date);
    };

    const renderCalendarDays = () => {
        const year = selectedDate.getFullYear();
        const month = selectedDate.getMonth();
        const firstDayOfMonth = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const days = [];

        // Add empty cells for days before the start of the month
        for (let i = 0; i < firstDayOfMonth; i++) {
            days.push(<div key={`empty-${i}`} className="calendar-day empty"></div>);
        }

        // Add days of the month
        for (let day = 2; day <= daysInMonth; day++) {
            const currentDate = new Date(year, month, day).toISOString().split('T')[0];
            const eventsForDay = userEvents.filter(event => event.date.split('T')[0] === currentDate);
            days.push(
                <div key={day} className="calendar-day">
                    <div className="day-number">{day-1}</div>
                    {eventsForDay.map(event => (
                        <div key={event.id} className="event">
                            <span className="event-name">{event.name}</span>
                            <span className="event-type">{event.type}</span>
                        </div>
                    ))}
                </div>
            );
        }

        return days;
    };

    if (loading) {
        return <LoadingCircle />;
    }

    if (error) {
        return <div className="error">{error.message}</div>;
    }

    return (
        <div className="calendar-container">
            <Sidebar id={id} />
            <div className="content">
                <h1>Choose date: Month</h1>
                <div className="date-picker">
                    <DatePicker
                        selected={selectedDate}
                        onChange={handleDateChange}
                        dateFormat="MMMM yyyy"
                        showMonthYearPicker
                    />
                </div>
                <div className="calendar-grid">
                    {renderCalendarDays()}
                </div>
            </div>
        </div>
    );
};

export default MyCalendar;

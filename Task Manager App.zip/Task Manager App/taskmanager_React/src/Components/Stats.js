import React, { useState, useEffect, useMemo } from 'react';
import Sidebar from './Sidebar';
import { useLocation } from 'react-router-dom';
import '../Styles/Stats.css';
import LoadingCircle from './LoadingCircle';
import axios from 'axios';
import { Bar, Pie } from 'react-chartjs-2';
import { Chart, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement } from 'chart.js';

Chart.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement);

const Stats = () => {
    const location = useLocation();
    const id = useMemo(() => location.state || {}, [location.state]);
    const [tasks, setTasks] = useState([]);
    const [userEvents, setEvents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchEventsAndTasks = async () => {
            try {
                const eventResponse = await axios.get(`https://localhost:7034/api/Events/ByUser/${id}`);
                setEvents(eventResponse.data);

                const taskResponse = await axios.get(`https://localhost:7034/api/UserTasks/ByUser/${id}`);
                setTasks(taskResponse.data);

                setLoading(false);
            } catch (error) {
                setLoading(false);
                setError(error);
                if (error.response) {
                    console.error('Error response:', error.response.data);
                    window.alert(`Error: ${error.response.data}`);
                } else if (error.request) {
                    console.error('Error request:', error.request);
                    window.alert('Error: No response received from the server.');
                } else {
                    console.error('Error message:', error.message);
                    window.alert(`Error: ${error.message}`);
                }
            }
        };

        fetchEventsAndTasks();
    }, [id]);

    if (loading) {
        return <LoadingCircle />;
    }
    if (error) {
        return <div className="error">{error.message}</div>;
    }

    const eventTypeData = {
        labels: [...new Set(userEvents.map(event => event.type))],
        datasets: [{
            label: 'Event Count by Type',
            data: [...new Set(userEvents.map(event => event.type))].map(type => userEvents.filter(event => event.type === type).length),
            backgroundColor: 'rgba(75, 192, 192, 0.6)',
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 1,
        }],
    };

    const taskStatusData = {
        labels: [...new Set(tasks.map(task => task.status))],
        datasets: [{
            label: 'Task Count by Status',
            data: [...new Set(tasks.map(task => task.status))].map(status => tasks.filter(task => task.status === status).length),
            backgroundColor: 'rgba(153, 102, 255, 0.6)',
            borderColor: 'rgba(153, 102, 255, 1)',
            borderWidth: 1,
        }],
    };

    const taskPriorityData = {
        labels: [...new Set(tasks.map(task => task.priority))],
        datasets: [{
            label: 'Task Count by Priority',
            data: [...new Set(tasks.map(task => task.priority))].map(priority => tasks.filter(task => task.priority === priority).length),
            backgroundColor: 'rgba(255, 159, 64, 0.6)',
            borderColor: 'rgba(255, 159, 64, 1)',
            borderWidth: 1,
        }],
    };

    return (
        <div className="stats-container">
            <Sidebar id={id} />
            <div className="content">
                <h1>Statistics</h1>
                <div className="chart">
                    <Bar data={eventTypeData} options={{ responsive: true, plugins: { legend: { position: 'top' }, title: { display: true, text: 'Event Count by Type' } } }} />
                </div>
                <div className="chart">
                    <Pie data={taskStatusData} options={{ responsive: true, plugins: { legend: { position: 'top' }, title: { display: true, text: 'Task Count by Status' } } }} />
                </div>
                <div className="chart">
                    <Bar data={taskPriorityData} options={{ responsive: true, plugins: { legend: { position: 'top' }, title: { display: true, text: 'Task Count by Priority' } } }} />
                </div>
            </div>
        </div>
    );
}

export default Stats;

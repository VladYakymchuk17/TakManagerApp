import React, { useState, useEffect, useMemo } from 'react';
import { useLocation } from 'react-router-dom';
import Sidebar from './Sidebar';
import '../Styles/Current.css'
import LoadingCircle from './LoadingCircle';
import { Button, Modal, Form, FormGroup, FormLabel, FormControl, ButtonGroup } from 'react-bootstrap';
import axios from "axios";
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import DatePicker from "react-datepicker";


const Current = () => {
    const location = useLocation();
    const id = useMemo(() => location.state || {}, [location.state]);
    const [tasks,setTasks] = useState([])
    const [userEvents, setEvents] = useState([])
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [taskName, setTaskName] = useState('');
    const [taskDate, setTaskDate] = useState(new Date());
    const [taskDecription, setTaskDescription] = useState('');
    const [taskPriority, setTaskPriority] = useState(0);
    const [taskEventId, setTaskEventId] = useState(0);
    const [taskStatus, setTaskStatus] =useState('New');
    const [eventName, setEventName] = useState('');
    const [eventDate, setEventDate] = useState(new Date());
    const [eventDescription, setEventDescription] = useState('');
    const [eventType, setEventType] = useState('');
    const [selectedEventName, setSelectedEvent] = useState('');
    const [showTask, setShowTask] = useState(false);
    const [showEvent, setShowEvent] = useState(false);
    const [selectedDate, setSelectedDate] = useState(new Date());
    const [events, setAllEvents] = useState([])
    const [selectedTask, setSelectedTask] = useState(null)
    const [selectedEvent, setSelectEvent] =useState(null);
    

    useEffect( () =>{
        
        const fetchEventsAndTasks = async ()=>{
            const requestObject ={
                dateTime: selectedDate.toISOString(),
                userId: id
            }
        await axios.post(`https://localhost:7034/api/Events/ByDay`,requestObject).then(res=>{
            
            setEvents(res.data);
            setLoading(false);
        }).catch (error=> {
            setLoading(false);
            setError(error)
            if (error.response) {
               
                console.error('Error response:', error.response.data);
                window.alert(`Error: ${error.response.data}`);
            } else if (error.request) {
                
                console.error('Error request:', error.request);
                window.alert('Error: No response received from the server.');
            } else {
                
                console.error('Error message:', error.message);
                window.alert(`Error: ${error.message}`);
            }
        })

        await axios.post(`https://localhost:7034/api/UserTasks/ByDay`, requestObject).then(res=>{
            
        setTasks(res.data);
        setLoading(false);
    }).catch (error=> {
        setLoading(false);
        setError(error)
        if (error.response) {
           
            console.error('Error response:', error.response.data);
            window.alert(`Error: ${error.response.data}`);
        } else if (error.request) {
            
            console.error('Error request:', error.request);
            window.alert('Error: No response received from the server.');
        } else {
            
            console.error('Error message:', error.message);
            window.alert(`Error: ${error.message}`);
        }
    })
    }
    fetchEventsAndTasks();
    
    
    },[userEvents,id, tasks,selectedDate])

    useEffect( () =>{
        
        const fetchEvents = async ()=>{
        await axios.get(`https://localhost:7034/api/Events/ByUser/${id}`).then(res=>{
            
            setAllEvents(res.data);
            setLoading(false);
        }).catch(err=>{
            setError(err);
            
        })
    }
    fetchEvents();
    
    },[events,id])

    const handleCloseTask = () => setShowTask(false);
    const handleShowTask = (task) => {
        setTaskDescription(task.description)
        setTaskName(task.name)
        setTaskPriority(task.priority)
        setTaskDate(new Date(task.dueDate))
        setTaskEventId(task.eventId)
        setTaskStatus(task.status)
        setShowTask(true);
        console.log(task);
        setSelectedTask(task);
        console.log(selectedTask)
    }
    const handleCloseEvent = () => setShowEvent(false);
    const handleShowEvent = (event) =>{ 
        setEventDate(new Date(event.date))
        setEventDescription(event.description)
        setEventName(event.name)
        setEventType(event.type)
        setShowEvent(true);
        console.log(event);
        setSelectEvent(event);
        console.log(selectedEvent);

    }

    const handleRegisterSubmitTask = async (e) => {
        e.preventDefault();
        const task = {
            "id": selectedTask.id,
            "eventId": taskEventId,
            "name": taskName,
            "dueDate": taskDate.toISOString(),
            "priority": taskPriority,
            "description": taskDecription,
            "status": taskStatus
        }
        selectedTask.name = taskName;
        selectedTask.eventId = taskEventId;
        selectedTask.dueDate = taskDate.toISOString();
        selectedTask.priority = taskPriority;
        selectedTask.description = taskDecription;
        selectedTask.status = taskStatus;
        await axios.put(`https://localhost:7034/api/UserTasks/${selectedTask.id}`, task).then(res=>{
            console.log(res.data);
            handleCloseTask();
        }).catch (error=> {
            setLoading(false);
            setError(error)
            if (error.response) {
               
                console.error('Error response:', error.response.data);
                window.alert(`Error: ${error.response.data}`);
            } else if (error.request) {
                
                console.error('Error request:', error.request);
                window.alert('Error: No response received from the server.');
            } else {
                
                console.error('Error message:', error.message);
                window.alert(`Error: ${error.message}`);
            }
        })

        
       
    };

    const changeEventName = (e) =>{
        setSelectedEvent(e.target.value);
        
        if(e.target.value==='No link'){
            setTaskEventId(0);
        }
        for(let i=0; i<events.length; i++){
            if(events[i].name===e.target.value){
                setTaskEventId(events[i].id);
            }
        }
    }

    const changeTaskStatus = async (e) =>{
        setTaskStatus(e.target.value);
        const task = {
            "id": selectedTask.id,
            "eventId": taskEventId,
            "name": taskName,
            "dueDate": taskDate.toISOString(),
            "priority": taskPriority,
            "description": taskDecription,
            "status": e.target.value
        }
        console.log(task);
        selectedTask.name = taskName;
        selectedTask.eventId = taskEventId;
        selectedTask.dueDate = taskDate.toISOString();
        selectedTask.priority = taskPriority;
        selectedTask.description = taskDecription;
        selectedTask.status = e.target.value;
        await axios.put(`https://localhost:7034/api/UserTasks/${selectedTask.id}`, task).then(res=>{
            console.log(res.data);
            handleCloseTask();
        }).catch (error=> {
            setLoading(false);
            setError(error)
            if (error.response) {
               
                console.error('Error response:', error.response.data);
                window.alert(`Error: ${error.response.data}`);
            } else if (error.request) {
                
                console.error('Error request:', error.request);
                window.alert('Error: No response received from the server.');
            } else {
                
                console.error('Error message:', error.message);
                window.alert(`Error: ${error.message}`);
            }
        })
        
    }

    const handleDateChange = (date)=>{
        setSelectedDate(date);
    }
    const handleDeleteEvent =async (event)=>{
        await axios.delete(`https://localhost:7034/api/Events/${event.id}`).then(res=>{
            console.log(res.data);
        })
    }

    const handleDeleteTask = async (task)=>{
        await axios.delete(`https://localhost:7034/api/UserTasks/${task.id}`).then(res=>{
            console.log(res.data);
        })
    }

    const handleRegisterSubmitEvent = async (e) => {
        e.preventDefault();
        const eventRequest = {
            "id": selectedEvent.id,
            "name": eventName,
            "description": eventDescription,
            "type": eventType,
            "date": eventDate.toISOString()
        }
        selectedEvent.name = eventName;
        selectedEvent.description = eventDescription;
        selectedEvent.type = eventType;
        selectedEvent.date = eventDate.toISOString();
        console.log(selectedEvent);
        await axios.put(`https://localhost:7034/api/Events/${selectedEvent.id}`, eventRequest).then(res=>{
            console.log(res.data);
            handleCloseEvent(); 
        }).catch (error=> {
            setLoading(false);
            setError(error)
            if (error.response) {
               
                console.error('Error response:', error.response.data);
                window.alert(`Error: ${error.response.data}`);
            } else if (error.request) {
                
                console.error('Error request:', error.request);
                window.alert('Error: No response received from the server.');
            } else {
                
                console.error('Error message:', error.message);
                window.alert(`Error: ${error.message}`);
            }
        })
        
        
    };


    if(loading){
        return <LoadingCircle/>
    }
    if(error){
        return <div className="errorMessage">{error}</div>
    }


    return (
        <div className="current-container">
            <Sidebar id={id} />
            <div className="content">
                <h1>Choose date</h1>
                <div className="date-picker">
                    <DatePicker selected={selectedDate} onChange={handleDateChange} />
                </div>
                             
                <div className="events-container">
                    <h1>Events for {selectedDate.toLocaleDateString()}</h1>
                    <div className="event-list">
                    {userEvents.map(event => (
                        <div className="event-item" key={event.id}>
                            <h3>{event.name}</h3>
                            <p>{event.description}</p>
                            <p>{new Date(event.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                            <div className="event-actions">
                                <EditIcon onClick={() => handleShowEvent(event)} />
                                <DeleteIcon onClick={() => handleDeleteEvent(event)} />
                            </div>
                        </div>
                    ))}
                </div>
                </div>
                <div className="tasks-container">
                    <h1>Tasks for {selectedDate.toLocaleDateString()}</h1>
                    <div className="task-list">
                        {tasks.map((task)=>(
                            <div key={task.id} className="task-item">
                           <select value={taskStatus} onChange={changeTaskStatus}>
                                <option value="New">New</option>
                                <option value="In progress">In progress</option>
                                <option value="Complete">Complete</option>
                                <option value="Canceled">Canceled</option>
                                <option value="Undone">Undone</option>
                           </select>
                           <h3>{task.name}</h3>
                            <p>{task.description}</p>
                            <p>{task.priority}</p>
                            <div className="task-actions">
                                <EditIcon onClick={() => handleShowTask(task)} />
                                <DeleteIcon onClick={() => handleDeleteTask(task)} />
                            </div>
                          </div>

                        ))}
                    </div>
                </div>


                <Modal show={showTask} onHide={handleCloseTask}>
                <Modal.Header closeButton>
                    <Modal.Title>Update task</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form onSubmit={handleRegisterSubmitTask}>
                        <FormGroup controlId="fromBasicNameTask">
                            <FormLabel>New Name</FormLabel>
                            <FormControl type="text" placeholder="Enter name of task" value={taskName} onChange={(e)=>{setTaskName(e.target.value)}}/>
                               
                        </FormGroup>

                        <FormGroup controlId="fromBasicDateTask">
                            <FormLabel>New Date</FormLabel>
                            <DatePicker label="Basic date picker" selected={taskDate} onChange={(date) => setTaskDate(date)}
                             showTimeSelect
                             dateFormat="Pp">
                                
                             </DatePicker>
                        </FormGroup>
                        <FormGroup controlId="fromBasicPriorityTask">
                            <FormLabel>New Priority</FormLabel>
                            <Form.Select aria-label="Priority" value={taskPriority} onChange={(e)=>{setTaskPriority(parseInt(e.target.value))}}>
                                <option value="1">One</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                                <option value="4">Four</option>
                                <option value="5">Five</option>
                            </Form.Select>
                        </FormGroup>
                        <FormGroup controlId="fromBasicEventTask">
                            <FormLabel>Link with new Event</FormLabel>
                            <Form.Select aria-label="EventId" value={selectedEventName} onChange={changeEventName}>
                                <option value='No link'>No link</option>
                                {
                                events.map(item=><option>{item.name}</option>) 
                                }
                            </Form.Select>
                        </FormGroup>
                        <Form.Group className="mb-3" controlId="fromBasicDescriptionTask">
                            <Form.Label>New Description</Form.Label>
                            <Form.Control as="textarea" rows={3}  value={taskDecription} onChange={(e)=>{setTaskDescription(e.target.value)}}/>
                              
                        </Form.Group>
                       
                        <FormGroup controlId="fromBasicButtons">
                            <ButtonGroup style={{ marginTop: '10px' }} className="buttonGroupOptions">
                                <Button variant="secondary" type="submit">Update task</Button>
                                <Button variant="secondary" onClick={handleCloseTask}>Cancel</Button>
                            </ButtonGroup>
                        </FormGroup>
                    </Form>
                </Modal.Body>
            </Modal>

            <Modal show={showEvent} onHide={handleCloseEvent}>
                <Modal.Header closeButton>
                    <Modal.Title>Update event</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form onSubmit={handleRegisterSubmitEvent}>
                        <FormGroup controlId="fromBasicNameEvent">
                            <FormLabel>New Name</FormLabel>
                            <FormControl type="text" placeholder="Enter name of event" value={eventName} onChange={(e)=>{setEventName(e.target.value)}}/>
                           
                        </FormGroup>

                        <FormGroup controlId="fromBasicDateTimeEvent">
                            <FormLabel> New Date </FormLabel>
                            <DatePicker
                            selected={eventDate} onChange={(date) => setEventDate(date)}
                            showTimeSelect
                            dateFormat="Pp"
                            />
                        </FormGroup>
                        <FormGroup controlId="fromBasicTypeEvent">
                            <FormLabel>New Type</FormLabel>
                            <Form.Select aria-label="type" value={eventType} onChange={(e)=>{setEventType(e.target.value)}}>
                                <option value="Social Events">Social Events</option>
                                <option value="Professional Events">Professional Events</option>
                                <option value="Cultural and Entertainment Events">Cultural and Entertainment Events</option>
                            </Form.Select>
                        </FormGroup>
                        <Form.Group className="mb-3" controlId="fromBasicDescriptionEvent">
                            <Form.Label>New Description</Form.Label>
                            <Form.Control as="textarea" rows={3} value={eventDescription} onChange={(e)=>{setEventDescription(e.target.value)}}/>
                                
                        </Form.Group>

                        <FormGroup controlId="fromBasicButtons">
                            <ButtonGroup style={{ marginTop: '10px' }} className="buttonGroupOptions">
                                <Button type="submit" variant="secondary">Update event</Button>
                                <Button variant="secondary" onClick={handleCloseEvent}>Cancel</Button>
                            </ButtonGroup>
                        </FormGroup>
                    </Form>
                </Modal.Body>
            </Modal>

                
            </div>
        </div>
        
    );
}
 
export default Current;
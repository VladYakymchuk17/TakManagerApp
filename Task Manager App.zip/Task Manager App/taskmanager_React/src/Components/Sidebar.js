import React,{ useEffect, useState } from "react";
import '../Styles/Sidebar.css'
import { SidebarData } from "./SidebarData";
import { Button, Modal, Form, FormGroup, FormLabel, FormControl, ButtonGroup } from 'react-bootstrap';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import axios from "axios";
import LoadingCircle from "./LoadingCircle";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import {  useNavigate } from "react-router-dom";



const Sidebar = ({ id }) => {
    const [showTask, setShowTask] = useState(false);
    const [showEvent, setShowEvent] = useState(false);
    const userId = id;
    const [error, setError] = useState(null);
    const [loading, setLoading] = useState(true);
    const [events, setEvents] = useState([])
    const navigate = useNavigate();
    const [user, setUser] = useState(null);
    const [taskName, setTaskName] = useState('');
    const [taskDate, setTaskDate] = useState(new Date());
    const [taskDecription, setTaskDescription] = useState('');
    const [taskPriority, setTaskPriority] = useState(0);
    const [taskEventId, setTaskEventId] = useState(0);
    const taskStatus ='New';
    const [eventName, setEventName] = useState('');
    const [eventDate, setEventDate] = useState(new Date());
    const [eventDescription, setEventDescription] = useState('');
    const [eventType, setEventType] = useState('');
    const [selectedEventName, setSelectedEvent] = useState('');



   
    useEffect( () =>{
        
        const fetchUser = async ()=>{
        await axios.get(`https://localhost:7034/api/Users/${userId}`).then(res=>{
           
            setUser(res.data);
            setLoading(false);
        }).catch(err=>{
            setError(err);
            
        })
    }
    fetchUser();
    
    },[user, userId])

    useEffect( () =>{
        
        const fetchEvents = async ()=>{
        await axios.get(`https://localhost:7034/api/Events/ByUser/${userId}`).then(res=>{
            
            setEvents(res.data);
            setLoading(false);
        }).catch(err=>{
            setError(err);
            
        })
    }
    fetchEvents();
    
    },[events,userId])


   

    

    const handleCloseTask = () => setShowTask(false);
    const handleShowTask = () => setShowTask(true);
    const handleCloseEvent = () => setShowEvent(false);
    const handleShowEvent = () => setShowEvent(true);

    const handleRegisterSubmitTask = async (e) => {
        e.preventDefault();
        
        const task = {
            "userId": userId,
            "eventId": taskEventId,
            "name": taskName,
            "dueDate": taskDate.toISOString(),
            "priority": taskPriority,
            "description": taskDecription,
            "status": taskStatus
        }
        await axios.post('https://localhost:7034/api/UserTasks', task).then(res =>{
        console.log(res.data);
        handleCloseTask();
            
    }).catch (error=> {
        setLoading(false);
        if (error.response) {
           
            console.error('Error response:', error.response.data);
            window.alert(`Error: ${error.response.data}`);
        } else if (error.request) {
            
            console.error('Error request:', error.request);
            window.alert('Error: No response received from the server.');
        } else {
            
            console.error('Error message:', error.message);
            window.alert(`Error: ${error.message}`);
        }
    })
    };

    const changeEventName = (e) =>{
        setSelectedEvent(e.target.value);
        
        if(e.target.value==='No link'){
            setTaskEventId(0);
        }
        for(let i=0; i<events.length; i++){
            if(events[i].name===e.target.value){
                setTaskEventId(events[i].id);
            }
        }
    }

    const handleRegisterSubmitEvent = async (e) => {
        e.preventDefault();
        const eventRequest = {
            "userId": userId,
            "name": eventName,
            "description": eventDescription,
            "type": eventType,
            "date": eventDate.toISOString()
        }
        await axios.post('https://localhost:7034/api/Events', eventRequest).then(res =>{
        console.log(res.data);
        handleCloseEvent();
            
    }).catch (error=> {
        setLoading(false);
        if (error.response) {
           
            console.error('Error response:', error.response.data);
            window.alert(`Error: ${error.response.data}`);
        } else if (error.request) {
            
            console.error('Error request:', error.request);
            window.alert('Error: No response received from the server.');
        } else {
            
            console.error('Error message:', error.message);
            window.alert(`Error: ${error.message}`);
        }
    })
    };

    if(loading){
        return <LoadingCircle></LoadingCircle>
    }
    if(error!=null){
        return <div>{error}</div>
    }



    return (
    <div className="Sidebar">
        <div className="profile">
        {user && (
                    <>
                        <div className="accountInfo">
                            <AccountCircleIcon />
                            <h5>Welcome, {user.username}</h5>
                        </div>
                        <div className="email">
                            <p>Email: {user.email}</p>
                        </div>
                    </>
                )}
        </div>
        <h2 className="headerOption">Options</h2>
        <ul className="SidebarList">
        {SidebarData.map((value, key) => {

            return <li key={key} className="row" onClick={()=>{ navigate(`${value.link}`, { state:  id  })}} 
            id={window.location.pathname===value.link ? "active" :""}>
                {" "}
                <div id="icon">{value.icon}</div>
                {" "}
                <div id="title">{value.title}</div>
            </li>



        })}
        </ul>
        <h2 className="headerOption">Actions</h2>
        <div className="sidebarActions">
                        <Button variant="outline-light" className="mr-2" onClick={handleShowTask}>Add task</Button>
                        <Button variant="outline-light" onClick={handleShowEvent}>Add event</Button>
        </div>

        <Modal show={showTask} onHide={handleCloseTask}>
                <Modal.Header closeButton>
                    <Modal.Title>Add task</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form onSubmit={handleRegisterSubmitTask}>
                        <FormGroup controlId="fromBasicNameTask">
                            <FormLabel>Name</FormLabel>
                            <FormControl type="text" placeholder="Enter name of task" value={taskName} onChange={(e)=>{setTaskName(e.target.value)}} />
                        </FormGroup>

                        <FormGroup controlId="fromBasicDateTask">
                            <FormLabel>Date </FormLabel>
                            <DatePicker label="Basic date picker" selected={taskDate} onChange={(date) => setTaskDate(date)}
                             showTimeSelect
                             dateFormat="Pp"/>
                        </FormGroup>
                        <FormGroup controlId="fromBasicPriorityTask">
                            <FormLabel>Priority</FormLabel>
                            <Form.Select aria-label="Priority" value={taskPriority} onChange={(e)=>{setTaskPriority(parseInt(e.target.value))}}>
                                <option value="1">One</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                                <option value="4">Four</option>
                                <option value="5">Five</option>
                            </Form.Select>
                        </FormGroup>
                        <FormGroup controlId="fromBasicEventTask">
                            <FormLabel>Link with Event</FormLabel>
                            <Form.Select aria-label="EventId" value={selectedEventName} onChange={changeEventName}>
                                <option value='No link'>No link</option>
                                {
                                events.map(item=><option>{item.name}</option>) 
                                }
                            </Form.Select>
                        </FormGroup>
                        <Form.Group className="mb-3" controlId="fromBasicDescriptionTask">
                            <Form.Label>Description</Form.Label>
                            <Form.Control as="textarea" rows={3}  value={taskDecription} onChange={(e)=>{setTaskDescription(e.target.value)}}/>
                        </Form.Group>
                        <FormGroup>
                            <Form.Label>Status</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="New"
                                aria-label="Disabled input example"
                                readOnly
                            />
                        </FormGroup>

                        <FormGroup controlId="fromBasicButtons">
                            <ButtonGroup style={{ marginTop: '10px' }} className="buttonGroupOptions">
                                <Button variant="secondary" type="submit">Add task</Button>
                                <Button variant="secondary" onClick={handleCloseTask}>Cancel</Button>
                            </ButtonGroup>
                        </FormGroup>
                    </Form>
                </Modal.Body>
            </Modal>

            <Modal show={showEvent} onHide={handleCloseEvent}>
                <Modal.Header closeButton>
                    <Modal.Title>Add event</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form onSubmit={handleRegisterSubmitEvent}>
                        <FormGroup controlId="fromBasicNameEvent">
                            <FormLabel>Name</FormLabel>
                            <FormControl type="text" placeholder="Enter name of event" value={eventName} onChange={(e)=>{setEventName(e.target.value)}} />
                        </FormGroup>

                        <FormGroup controlId="fromBasicDateTimeEvent">
                            <FormLabel>Date </FormLabel>
                            <DatePicker
                            selected={eventDate} onChange={(date) => setEventDate(date)}
                            showTimeSelect
                            dateFormat="Pp"
                            />
                        </FormGroup>
                        <FormGroup controlId="fromBasicTypeEvent">
                            <FormLabel>Type</FormLabel>
                            <Form.Select aria-label="type" value={eventType} onChange={(e)=>{setEventType(e.target.value)}}>
                                <option value="Social Events">Social Events</option>
                                <option value="Professional Events">Professional Events</option>
                                <option value="Cultural and Entertainment Events">Cultural and Entertainment Events</option>
                            </Form.Select>
                        </FormGroup>
                        <Form.Group className="mb-3" controlId="fromBasicDescriptionEvent">
                            <Form.Label>Description</Form.Label>
                            <Form.Control as="textarea" rows={3} value={eventDescription} onChange={(e)=>{setEventDescription(e.target.value)}}/>
                        </Form.Group>

                        <FormGroup controlId="fromBasicButtons">
                            <ButtonGroup style={{ marginTop: '10px' }} className="buttonGroupOptions">
                                <Button type="submit" variant="secondary">Add event</Button>
                                <Button variant="secondary" onClick={handleCloseEvent}>Cancel</Button>
                            </ButtonGroup>
                        </FormGroup>
                    </Form>
                </Modal.Body>
            </Modal>


    </div>  
    
);
}
 
export default Sidebar;
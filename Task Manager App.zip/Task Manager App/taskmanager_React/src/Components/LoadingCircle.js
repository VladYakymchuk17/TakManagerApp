import '../Styles/Loading.css';

const LoadingCircle = () => {
    return ( 
        <div className="loading"></div>
     );
}
 
export default LoadingCircle;
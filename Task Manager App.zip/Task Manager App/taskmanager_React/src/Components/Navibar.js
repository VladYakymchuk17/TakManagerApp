import React, {useEffect, useState} from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button, Navbar,Nav, Modal, ModalHeader, ModalTitle, ModalBody, Form, FormGroup, FormLabel, FormControl, FormText, Container, ButtonGroup} from "react-bootstrap";
import styled from "styled-components";
import axios from "axios";
import LoadingCircle from "./LoadingCircle";
import AlertMesssage from "./AlertMessage";

const Styles = styled.div `
a, .navbar-brand, .navbar-nav .nav-link{
    color: #adb1b8;
    &:hover{
        color:white
    }
}
`
const Navibar = () => {

    const [loading,setLoading] = useState(false);
    const [show, setShow] = useState(false);
    const [username, setUsername] = useState('')
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [isLogin, setIsLogin] = useState(false)
    const [users,setUsers] = useState([])
    const [alert, setAlert] = useState({ message: '', severity: '' });
    const [showAlert, setShowAlert] = useState(false);


    useEffect( ()=>{
        const fetchUsers = async()=>{
            await axios.get('https://localhost:7034/api/Users').then(res=>{
                setUsers(res.data);
                });

        }
        fetchUsers();


    }, [users])

    const navigate = useNavigate();

    const handleClose =() => setShow(false);
    const handleShow =() => setShow(true);

    const handleLogin = async()=>{
        
        setIsLogin(true);
    }

    const handleSignIn = ()=>{
        setIsLogin(false);
    }

    const handleRegisterSubmit = async(e)=>{
        e.preventDefault();
        setLoading(true);
        
        const user ={
            username: username,
            email : email,
            password: password
        }
        if(isLogin){
           
            if(users!=null){
                let found = false;
                for(let i=0;i<users.length;i++){
                    if(users[i].email === user.email&& users[i].password===user.password&& users[i].username === user.username){
                            //window.alert("User was found");
                            setAlert({ message: "User was found", severity: "success" });
                            setShowAlert(true);
                            setTimeout(() => {
                                setShowAlert(false);
                            }, 5000); // 5 seconds
                            
                            found =true;
                            navigate('/page', { state:  users[i].id  });
                            setEmail('')
                            setPassword('')
                            setUsername('');
                           
                            setLoading(false);
                            handleClose();

                    }
                }
                if(!found){
                  // window.alert("No such user, try to sign up");
                    setAlert({ message: "No such user, try to sign up", severity: "error" });
                    setShowAlert(true);
                    setTimeout(() => {
                        setShowAlert(false);
                    }, 5000); // 5 seconds
                    setLoading(false);

                }
            }else{
                //window.alert("Sorry no users, maybe you`ll be first. Sign up");
                setAlert({ message: "Sorry no users, maybe you`ll be first. Sign up", severity: "info" });
                setShowAlert(true);
                setTimeout(() => {
                    setShowAlert(false);
                }, 5000); // 5 seconds
                setLoading(false);

                
            }


        }else{
           
            await axios.post('https://localhost:7034/api/Users', user).then(res =>{
                
                navigate('/page', { state:  res.data.id  });
                setEmail('')
                setPassword('')
                setUsername('');
                setLoading(false);
                handleClose();
                    
            }).catch (error=> {
                setLoading(false);
                if (error.response) {
                   
                    console.error('Error response:', error.response.data);
                   // window.alert(`Error: ${error.response.data}`);
                   setAlert({ message: `Error: ${error.response.data}`, severity: "error" });
                   setShowAlert(true);
                   setTimeout(() => {
                    setShowAlert(false);
                }, 5000); // 5 seconds
                } else if (error.request) {
                    
                    console.error('Error request:', error.request);
                    //window.alert('Error: No response received from the server.');
                    setAlert({ message: 'Error: No response received from the server.', severity: "error" });
                    setShowAlert(true);
                    setTimeout(() => {
                        setShowAlert(false);
                    }, 5000); // 5 seconds
                } else {
                    
                    console.error('Error message:', error.message);
                    //window.alert(`Error: ${error.message}`);
                    setAlert({ message: `Error: ${error.message}`, severity: "error" });
                    setShowAlert(true);
                    setTimeout(() => {
                        setShowAlert(false);
                    }, 5000); // 5 seconds
                }
            })

            


        }
       

    }

    if(loading ){
        return <LoadingCircle/>;
    }

    return ( 
    <>
    {showAlert && <AlertMesssage message={alert.message} severity={alert.severity}/>}
    <Styles>
    <Navbar collapseOnSelect expand='lg' bg="dark" variant="dark">
        <Container>
            <Navbar.Brand>Task Manager</Navbar.Brand>
            <Navbar.Toggle aria-controls = 'responsive-navbar-nav'></Navbar.Toggle>
            <Navbar.Collapse id = 'responsive-navbar-nav'>
            <Nav className='mr-auto'>
                <Nav.Link>  <Link style={{textDecoration: 'none'}} to='/'>Home</Link>    </Nav.Link>
                <Nav.Link>  <Link style={{textDecoration: 'none'}} to='/about'>About</Link>  </Nav.Link>

            </Nav>
            <Nav style={{'marginLeft': '800px'}}>
                <Button variant="primary" className="mr-2" onClick={handleShow}>Log in</Button>
                <Button variant="secondary"><Link style={{textDecoration: 'none', color:'white'}} to="/">Sign out</Link></Button>
            </Nav>
            </Navbar.Collapse>
        </Container>

    </Navbar>
    </Styles>
    <Modal show={show} onHide={handleClose}>
            <ModalHeader closeButton>
                <ModalTitle>Log in</ModalTitle>

            </ModalHeader>
            <ModalBody>
                <Form onSubmit={handleRegisterSubmit}>
                    <FormGroup controlId="fromBasicUsername">
                        <FormLabel>
                            Username
                        </FormLabel>
                        <FormControl type="text" placeholder="Enter username" value={username} onChange={(e)=> setUsername(e.target.value)}/>
                    </FormGroup>
                    <FormGroup controlId="fromBasicEmail">
                        <FormLabel>
                            Email address
                        </FormLabel>
                        <FormControl type="email" placeholder="Enter email" value={email} onChange={(e)=> setEmail(e.target.value)}/>
                        <FormText className="textMuted">We`ll not share this email with others</FormText>

                    </FormGroup>

                    <FormGroup controlId="fromBasicPassword">
                        <FormLabel>
                            Password
                        </FormLabel>
                        <FormControl type="password" placeholder="Enter password" value={password} onChange={(e)=> setPassword(e.target.value)}/>
                        
                    </FormGroup>

                    <FormGroup controlId="fromBasicButtons">
                        <ButtonGroup style={{marginTop:'10px'}} className="buttonGroupOptions">

                            <Button variant="secondary" type="submit" onClick={handleLogin} >Log in</Button>
                            <Button variant="secondary" type="submit" onClick={handleSignIn}>Sign in</Button>
                        </ButtonGroup>
                        
                    </FormGroup>

                    
                </Form>
            </ModalBody>
        </Modal>
    
    
    
    
    
    </> 
    );
}
 
export default Navibar;
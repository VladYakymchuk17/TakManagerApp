import React, { useState } from 'react';
import { Link} from 'react-router-dom';
import {  Nav, Button, Modal, Form, FormGroup, FormLabel, FormControl,  ButtonGroup} from 'react-bootstrap';
import styled from 'styled-components';

const Styles = styled.div`
    .sidebar {
        height: 100vh;
        position: fixed;
        left: 0;
        top: 0;
        width: 250px;
        background-color: #f8f9fa;
        border-right: 1px solid #dee2e6;
        padding-top: 20px;
    }
    .sidebar a {
        padding: 10px 15px;
        text-decoration: none;
        font-size: 18px;
        color: #343a40;
        display: block;
    }
    .sidebar a:hover {
        background-color: #343a40;
        color: white;
    }
    .content {
        margin-left: 260px;
        padding: 20px;
    }
`;

const PersonalNavbar = () => {
    const [showTask, setShowTask] = useState(false);
    const [showEvent, setShowEvent] = useState(false);

    

    const handleCloseTask = () => setShowTask(false);
    const handleShowTask = () => setShowTask(true);
    const handleCloseEvent = () => setShowEvent(false);
    const handleShowEvent = () => setShowEvent(true);

    const handleRegisterSubmit = async (e) => {
        e.preventDefault();
    };

    return (
        <>
            <Styles>
                <div className="sidebar">
                    <h2>Personal Page</h2>
                    <Nav>
                        <Nav.Link as={Link} to='/current'>Current</Nav.Link>
                        <Nav.Link as={Link} to='/calendar'>Calendar</Nav.Link>
                        <Nav.Link as={Link} to='/stats'>Progress</Nav.Link>
                    </Nav>
                    <div style={{ marginTop: '20px' }}>
                        <Button variant="primary" className="mr-2" onClick={handleShowTask}>Add task</Button>
                        <Button variant="secondary" onClick={handleShowEvent}>Add event</Button>
                    </div>
                </div>
                <div className="content">
                    {/* Content here will be pushed to the right by the sidebar */}
                </div>
            </Styles>

            <Modal show={showTask} onHide={handleCloseTask}>
                <Modal.Header closeButton>
                    <Modal.Title>Add task</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form onSubmit={handleRegisterSubmit}>
                        <FormGroup controlId="fromBasicNameTask">
                            <FormLabel>Name</FormLabel>
                            <FormControl type="text" placeholder="Enter name of task" />
                        </FormGroup>

                        <FormGroup controlId="fromBasicDateTask">
                            <FormLabel>Date</FormLabel>
                            <FormControl type="text" placeholder="Enter due date of task" />
                        </FormGroup>
                        <FormGroup controlId="fromBasicPriorityTask">
                            <FormLabel>Priority</FormLabel>
                            <Form.Select aria-label="Priority">
                                <option value="1">One</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                                <option value="4">Four</option>
                                <option value="5">Five</option>
                            </Form.Select>
                        </FormGroup>
                        <Form.Group className="mb-3" controlId="fromBasicDescriptionTask">
                            <Form.Label>Description</Form.Label>
                            <Form.Control as="textarea" rows={3} />
                        </Form.Group>
                        <FormGroup>
                            <Form.Label>Status</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="New"
                                aria-label="Disabled input example"
                                readOnly
                            />
                        </FormGroup>

                        <FormGroup controlId="fromBasicButtons">
                            <ButtonGroup style={{ marginTop: '10px' }} className="buttonGroupOptions">
                                <Button variant="secondary">Add task</Button>
                                <Button variant="secondary" onClick={handleCloseTask}>Cancel</Button>
                            </ButtonGroup>
                        </FormGroup>
                    </Form>
                </Modal.Body>
            </Modal>

            <Modal show={showEvent} onHide={handleCloseEvent}>
                <Modal.Header closeButton>
                    <Modal.Title>Add event</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form onSubmit={handleRegisterSubmit}>
                        <FormGroup controlId="fromBasicNameEvent">
                            <FormLabel>Name</FormLabel>
                            <FormControl type="text" placeholder="Enter name of event" />
                        </FormGroup>

                        <FormGroup controlId="fromBasicDateEvent">
                            <FormLabel>Date</FormLabel>
                            <FormControl type="text" placeholder="Enter date of event" />
                        </FormGroup>
                        <FormGroup controlId="fromBasicTypeEvent">
                            <FormLabel>Type</FormLabel>
                            <Form.Select aria-label="Priority">
                                <option value="Social Events">Social Events</option>
                                <option value="Professional Events">Professional Events</option>
                                <option value="Cultural and Entertainment Events">Cultural and Entertainment Events</option>
                            </Form.Select>
                        </FormGroup>
                        <Form.Group className="mb-3" controlId="fromBasicDescriptionEvent">
                            <Form.Label>Description</Form.Label>
                            <Form.Control as="textarea" rows={3} />
                        </Form.Group>

                        <FormGroup controlId="fromBasicButtons">
                            <ButtonGroup style={{ marginTop: '10px' }} className="buttonGroupOptions">
                                <Button variant="secondary">Add event</Button>
                                <Button variant="secondary" onClick={handleCloseEvent}>Cancel</Button>
                            </ButtonGroup>
                        </FormGroup>
                    </Form>
                </Modal.Body>
            </Modal>
        </>
    );
};

export default PersonalNavbar;

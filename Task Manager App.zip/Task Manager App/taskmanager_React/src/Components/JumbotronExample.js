import React from "react";
import { Col, Container, Row } from "react-bootstrap";
import backgroundImage from '../Images/Free-startup-task-management.png'

const JumbotronExample = () => {
    return ( 

        <div className="overlay">
        <Container>
            <Row>
                <Col>
                    <h1>Task Management App</h1>
                    <p>Welcome to our Task Management App, your ultimate solution for organizing and optimizing your daily tasks. Whether you are a busy professional juggling multiple projects, a student managing assignments, or anyone looking to streamline their workflow, our app is designed to help you stay on top of your responsibilities and achieve your goals.

                    Our app offers a user-friendly interface that allows you to easily create, prioritize, and track your tasks. With features like customizable to-do lists, calendar integration, and visual project boards, you can choose the task management style that best suits your needs. The flexibility of our app ensures that you can adapt it to your personal workflow, enhancing productivity and reducing stress.

                    Key Features:

                    Intuitive Task Creation: Quickly add tasks with due dates, priorities, and descriptions to keep everything organized.
                    Visual Boards: Use Kanban-style boards to visually manage tasks and projects, making it easy to see what needs to be done at a glance.
                    Calendar Integration: Sync your tasks with your calendar to ensure you never miss a deadline.
                    Notifications and Reminders: Set up reminders to stay on track and get notified of upcoming tasks and deadlines.
                    Collaboration Tools: Share tasks and projects with team members, making it easier to collaborate and track progress together.
                    Our mission is to provide you with a powerful tool that simplifies task management and enhances productivity. We believe that by offering a comprehensive solution, we can help you focus on what truly matters, achieving your goals efficiently and effectively.

                    Join us on this journey towards better task management and discover how our app can transform the way you work. Start organizing, prioritizing, and accomplishing more today with our Task Management App!

                    </p>
                </Col>
                <Col>
                    <img  className="d-block w-100"
                            src={backgroundImage}
                            alt="Task management" 
                    ></img>
                </Col>
            </Row>
            
           
        </Container>


    </div>


     );
}
 
export default JumbotronExample;
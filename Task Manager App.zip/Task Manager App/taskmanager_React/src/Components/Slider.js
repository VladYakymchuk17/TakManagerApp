import React from "react";

import { Carousel, CarouselCaption, CarouselItem} from "react-bootstrap";
import whatIs from '../Images/what-is-task-management.png'
import busy from '../Images/tasksBusy2.png'
import alotTasks from '../Images/management.jpg'



const Slider = () => {
    const imageStyle = {
        height:'800px',
        width: '700px'
    };

    const textStyle ={
        color:'black',
        backgroundColor: "lightblue"
    }
    return (
        <Carousel>

             <CarouselItem style={{'height': '800px'}}> 
                <img className="d-block w-100"
                src={busy}
                alt="Ssecond slide"
                style={imageStyle}/>

                <CarouselCaption style={textStyle}>
                    <h3>Overwhelmed by Tasks? </h3>
                    <p>Do you feel overwhelmed by the sheer number of tasks you need to handle? Our character here certainly does! Balancing multiple responsibilities can lead to stress and decreased productivity </p>
                </CarouselCaption>

            </CarouselItem>

            <CarouselItem style={{'height': '900px'}}>
                <img className="d-block w-100"
                src={whatIs}
                alt="First slide"
                style={imageStyle}/>

                <CarouselCaption style={textStyle}>
                    <h3>Introduction to Task Management</h3>
                    <p>In this slide, we explore the basics of task management. Task management involves organizing, prioritizing, and tracking tasks to ensure productivity and efficiency</p>
                </CarouselCaption>

            </CarouselItem>

            <CarouselItem style={{'height': '900px'}}>
                <img className="d-block w-100"
                src={alotTasks}
                alt="Third slide"
                style={imageStyle}/>

                <CarouselCaption style={textStyle}>
                    <h3>Effective Task Management Solutions </h3>
                    <p>Let's explore some tools and techniques that can help you master task management and achieve your goals </p>
                </CarouselCaption>

            </CarouselItem>
            


        </Carousel>
        
    
    
    );
}
 
export default Slider;
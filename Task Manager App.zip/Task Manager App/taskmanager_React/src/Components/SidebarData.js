import React from "react"
import AssignmentIcon from '@mui/icons-material/Assignment';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import QueryStatsIcon from '@mui/icons-material/QueryStats';

export const SidebarData =[
    {
        title:'Current tasks',
        link: '/current',
        icon: <AssignmentIcon/>

    },
    {
        title:'Event calendar',
        link: '/calendar',
        icon: <CalendarMonthIcon/>

    },
    {
        title:'Stats',
        link: '/stats',
        icon: <QueryStatsIcon/>

    }
] 
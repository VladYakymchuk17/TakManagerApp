import JumbotronExample from "./JumbotronExample";

const About = () => {
    return ( 
        <JumbotronExample></JumbotronExample>
    );
}
 
export default About;
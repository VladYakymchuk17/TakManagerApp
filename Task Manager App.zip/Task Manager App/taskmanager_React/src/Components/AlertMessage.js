import Alert from '@mui/material/Alert';


const AlertMesssage = ({message, severity}) => {
    return ( 
        <Alert variant="outlined" severity={severity}>
        {message}
        </Alert>
     );
}
 
export default AlertMesssage;
import React from 'react';
import { useLocation } from 'react-router-dom';
import Sidebar from './Sidebar';
import '../Styles/PersonalPage.css'

const PersonalPage = () => {
    const location = useLocation();
    const id  = location.state || {};
    console.log(id); // Destructure the state
    

    return (
        <>
       
        <Sidebar  id={id}/>

    
        </>
    );
};

export default PersonalPage;

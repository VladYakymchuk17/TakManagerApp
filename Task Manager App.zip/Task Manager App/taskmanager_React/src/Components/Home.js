import { useState } from "react";
import { Card, CardImg, Col, Row, Container, CardBody, CardText, Button, Modal, Form, FormGroup, FormLabel } from "react-bootstrap";
import Slider from "./Slider";
import task from '../Images/taskCard.png'
import login from '../Images/login2.jpg'
import result from '../Images/result.png'

const Home = () => {
    const [isLogInfo, setIsLogInfo] = useState(false)
    const [isAddInfo, setIsAddInfo] = useState(false)
    const [isStatInfo, setIsStatInfo] = useState(false)
  


    const handleShowLogInfo = ()=>setIsLogInfo(true);
    

    const handleCloseLogInfo = ()=>setIsLogInfo(false);

    const handleShowAddInfo = ()=>setIsAddInfo(true);
    

    const handleCloseAddInfo = ()=>setIsAddInfo(false);

    const handleShowStatInfo = ()=>setIsStatInfo(true);
    

    const handleCloseStatInfo = ()=>setIsStatInfo(false);
   


    return (
        <>
        <Slider/>
        <Container style={{paddingTop: '2rem', paddingBottom:'2rem'}}>
            <Row>
                <Col>
                    <Card style={{width: '18rem'}}>
                        <CardImg variant="top" src={login}  />
                        <CardBody>
                            <CardText>
                                First log in or sign up into the system by entering username, password and email

                            </CardText>
                            <Button variant="info" onClick={handleShowLogInfo}> More Info...</Button>

                        </CardBody>

                    

                    </Card>
                
                </Col>

            
            <Col>
                <Card style={{width: '18rem'}}>
                    <CardImg variant="top" src={task}  />
                    <CardBody>
                        <CardText>
                            Then create your task and try to do it
                        </CardText>
                        <Button variant="info" onClick={handleShowAddInfo}> More Info...</Button>

                    </CardBody>

                   

                </Card>
                
                </Col>

                <Col>
                <Card style={{width: '18rem'}}>
                    <CardImg variant="top" src={result}  />
                    <CardBody>
                        <CardText>
                            After check your progress
                        </CardText>
                        <Button variant="info" onClick={handleShowStatInfo}> More Info...</Button>

                    </CardBody>

                   

                </Card>
                
                </Col>
                </Row>

        </Container>

        <Modal show={isLogInfo} onHide={handleCloseLogInfo}>
                <Modal.Header closeButton>
                    <Modal.Title>Explanation for logging in: </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form >
                        <FormGroup controlId="fromBasic">
                            <FormLabel>1. First enter in all neccessary fields,like: email, password and username </FormLabel>
                           
                        </FormGroup>

                        <FormGroup controlId="fromBasic">
                            <FormLabel>2. Wait if there any problems </FormLabel>
                            
                        </FormGroup>
                        <FormGroup controlId="fromBasic">
                            <FormLabel>3. If you redirected to your page, you have done everything right</FormLabel>
                           
                        </FormGroup>
                        <FormGroup controlId="fromBasic">
                            <FormLabel>4. If you get some error, like there is no such user, try signing up instead of logging in</FormLabel>
                           
                        </FormGroup>
                        <Form.Group className="mb-3" controlId="fromBasic">
                            <Form.Label>5. If you get message about that such user exists try to replace your email and username</Form.Label>
                           
                        </Form.Group>
                        <FormGroup>
                            <Form.Label>6. Be careful with writing correct email</Form.Label>
                           
                        </FormGroup>

                        <FormGroup controlId="fromBasicButtons">
                                <Button variant="secondary" onClick={handleCloseLogInfo}>Done</Button>
                        </FormGroup>
                    </Form>
                </Modal.Body>
            </Modal>

            <Modal show={isAddInfo} onHide={handleCloseAddInfo}>
                <Modal.Header closeButton>
                    <Modal.Title>Explanation for adding tasks and events: </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form >
                        <FormGroup controlId="fromBasic">
                            <FormLabel>1. Press add task or add event buttons in actions of sidebar</FormLabel>
                           
                        </FormGroup>

                        <FormGroup controlId="fromBasic">
                            <FormLabel>2. Then fill all fields</FormLabel>
                            
                        </FormGroup>
                        <FormGroup controlId="fromBasic">
                            <FormLabel>3. Wait if there errors for 5 seconds</FormLabel>
                           
                        </FormGroup>
                        <FormGroup controlId="fromBasic">
                            <FormLabel>4. If you dont see anything, go to current page option</FormLabel>
                           
                        </FormGroup>
                        <Form.Group className="mb-3" controlId="fromBasic">
                            <Form.Label>5. Here you can check if adding went well</Form.Label>
                           
                        </Form.Group>
                        <FormGroup>
                            <Form.Label>6. If you get error try to check fields, there can be mistake</Form.Label>
                           
                        </FormGroup>

                        <FormGroup controlId="fromBasicButtons">
                                <Button variant="secondary" onClick={handleCloseAddInfo}>Done</Button>
                        </FormGroup>
                    </Form>
                </Modal.Body>
            </Modal>

            <Modal show={isStatInfo} onHide={handleCloseStatInfo}>
                <Modal.Header closeButton>
                    <Modal.Title>Explanation for checking stats: </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form >
                        <FormGroup controlId="fromBasic">
                            <FormLabel>1. Click on stats option</FormLabel>
                           
                        </FormGroup>

                        <FormGroup controlId="fromBasic">
                            <FormLabel>2. Here you`ll see some charts </FormLabel>
                            
                        </FormGroup>
                        <FormGroup controlId="fromBasic">
                            <FormLabel>3. Click charts and see what info it shows</FormLabel>
                           
                        </FormGroup>
                        <FormGroup controlId="fromBasic">
                            <FormLabel>4. Check you statistic through time</FormLabel>
                           
                        </FormGroup>
                        <Form.Group className="mb-3" controlId="fromBasic">
                            <Form.Label>5. You can analyze your events, tasks and plan for improvements</Form.Label>
                           
                        </Form.Group>
                        <FormGroup>
                            <Form.Label>6. Enjoy your results</Form.Label>
                           
                        </FormGroup>

                        <FormGroup controlId="fromBasicButtons">
                                <Button variant="secondary" onClick={handleCloseStatInfo}>Done</Button>
                        </FormGroup>
                    </Form>
                </Modal.Body>
            </Modal>
        </>
        


     );
}
 
export default Home;

import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navibar from './Components/Navibar';
import Home from './Components/Home';
import Users from './Components/Users';
import About from './Components/About';
import PersonalPage from './Components/PersonalPage';
import Current from './Components/Current';
import MyCalendar from './Components/MyCalendar';
import Stats from './Components/Stats'


function App() {
  return (
    <>
    <Router>
      <Navibar/>
      <Routes>
        <Route path='/' element={<Home/>}></Route>
        <Route path='/users' element={<Users/>}></Route>
        <Route path='/about' element={<About/>}></Route>
        <Route path='/page' element={<PersonalPage/>}></Route>
        <Route path='/current' element={<Current/>}></Route>
        <Route path='/calendar' element={<MyCalendar/>}></Route>
        <Route path='/stats' element={<Stats/>}></Route>
      </Routes>

      



    </Router>
    
    
    
    </>
  );
}

export default App;

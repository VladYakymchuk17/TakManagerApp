﻿using System.Net.Mail;

namespace WebApiTaskManagement.Validation
{
    public class EmailValidator
    {
        public EmailValidator() { }
        public bool IsValid(string email)
        {
            var valid = true;

            try
            {
                var emailAddress = new MailAddress(email);
            }
            catch
            {
                valid = false;
            }

            return valid;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApiTaskManagement.Data;
using WebApiTaskManagement.Models;
using WebApiTaskManagement.RequestModels;

namespace WebApiTaskManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventsController : ControllerBase
    {
        private readonly TaskManagementContext _context;

        public EventsController(TaskManagementContext context)
        {
            _context = context;
        }

        // GET: api/Events
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Event>>> GetEvents()
        {
          if (_context.Events == null)
          {
              return NotFound();
          }
            return await _context.Events.ToListAsync();
        }

        // GET: api/Events/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Event>> GetEvent(int id)
        {
          if (_context.Events == null)
          {
              return NotFound();
          }
            var @event = await _context.Events.FindAsync(id);

            if (@event == null)
            {
                return NotFound();
            }

            return @event;
        }

        [HttpGet("ByUser/{id}")]
        public async Task<ActionResult<IEnumerable<Event>>> GetEventsByUser(int id)
        {
            if (_context.Events == null)
            {
                return NotFound();
            }
            List<Event> events = new List<Event>();
            foreach (var item in _context.Events)
            {
                if(item.UserId == id)
                {
                   
                        events.Add(item);
                    
                }
                
            }
            return Ok(events);

        }


        [HttpGet("TodayByUser/{id}")]
        public async Task<ActionResult<IEnumerable<Event>>> GetEventsTodayByUser(int id)
        {
            if (_context.Events == null)
            {
                return NotFound();
            }
            List<Event> events = new List<Event>();
            foreach (var item in _context.Events)
            {
                if (item.UserId == id)
                {
                    if (item.Date.Date == DateTime.Now.Date)
                    {

                        events.Add(item);

                    }

                }

            }
            return Ok(events);

        }


        [HttpPost]
        [Route("ByDay")]
        public async Task<ActionResult<IEnumerable<Event>>> GetEventsByDay(EventGetByDay byDay)
        {
            if (_context.Events == null)
            {
                return NotFound();
            }
            List<Event> events = new List<Event>();
            foreach (var item in _context.Events)
            {
                if (item.UserId == byDay.UserId)
                {
                    if (item.Date.Date == byDay.DateTime.Date)
                    {

                        events.Add(item);

                    }

                }

            }
            return Ok(events);

        }

        [HttpPost]
        [Route("ByMonth")]
        public async Task<ActionResult<IEnumerable<Event>>> GetEventsByMonth(GetEventMonth byDay)
        {
            if (_context.Events == null)
            {
                return NotFound();
            }
            List<Event> events = new List<Event>();
            foreach (var item in _context.Events)
            {
                if (item.UserId == byDay.UserId)
                {
                    if (item.Date >= byDay.StartDateTime&&item.Date<=byDay.EndDateTime)
                    {

                        events.Add(item);

                    }

                }

            }
            return Ok(events);

        }


        // PUT: api/Events/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutEvent(int id, EventPutRequest addRequest)
        {
            if (id != addRequest.Id)
            {
                return BadRequest();
            }

            // Find the event with the specified ID
            var existingEvent = await _context.Events.FindAsync(id);

            if (existingEvent == null)
            {
                return NotFound();
            }

            // Update the properties
            existingEvent.Date = addRequest.Date;
            existingEvent.Name = addRequest.Name;
            existingEvent.Description = addRequest.Description;
            existingEvent.Type = addRequest.Type;

            try
            {
                // Save the changes to the database
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EventExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // Method to check if the event exists
      

        // POST: api/Events
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Event>> PostEvent(EventAddRequest myEvent)
        {
            if (_context.Events == null)
            {

                return Problem("Entity set 'TaskManagementContext.Events'  is null.");
            }

            if(myEvent.Date.Month< DateTime.Now.Month)
            {
                return BadRequest("The date is invalid");
            }
            foreach(var item in _context.Events)
            {
                if(myEvent.UserId == item.UserId)
                {
                    if(myEvent.Name == item.Name)
                    {
                        return BadRequest("There is event with such name, please chnge name");
                    }
                }
            }
            Event newEvent = new Event();
            newEvent.Date = myEvent.Date;
            newEvent.Name = myEvent.Name;
            newEvent.Description = myEvent.Description;
            newEvent.Type = myEvent.Type;
            newEvent.UserId = myEvent.UserId; 

          



             _context.Events.Add(newEvent);
             await _context.SaveChangesAsync();

             return CreatedAtAction("GetEvent", new { id = newEvent.Id }, newEvent);
        }

        // DELETE: api/Events/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEvent(int id)
        {
            if (_context.Events == null)
            {
                return NotFound();
            }
            var @event = await _context.Events.FindAsync(id);
            if (@event == null)
            {
                return NotFound();
            }

            _context.Events.Remove(@event);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool EventExists(int id)
        {
            return (_context.Events?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}

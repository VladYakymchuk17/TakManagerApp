﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApiTaskManagement.Data;
using WebApiTaskManagement.Models;
using WebApiTaskManagement.RequestModels;

namespace WebApiTaskManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserTasksController : ControllerBase
    {
        private readonly TaskManagementContext _context;

        public UserTasksController(TaskManagementContext context)
        {
            _context = context;
        }

        // GET: api/UserTasks
        [HttpGet]
        public async Task<ActionResult<IEnumerable<UserTask>>> GetTasks()
        {
          if (_context.Tasks == null)
          {
              return NotFound();
          }
            return await _context.Tasks.ToListAsync();
        }

        // GET: api/UserTasks/5
        [HttpGet("{id}")]
        public async Task<ActionResult<UserTask>> GetUserTask(int id)
        {
          if (_context.Tasks == null)
          {
              return NotFound();
          }
            var userTask = await _context.Tasks.FindAsync(id);

            if (userTask == null)
            {
                return NotFound();
            }

            return userTask;
        }


        [HttpGet("ByUser/{id}")]
        public async Task<ActionResult<IEnumerable<UserTask>>> GetUserTaskByUser(int id)
        {
            if (_context.Tasks == null)
            {
                return NotFound();
            }
            List<UserTask> userTasks = new List<UserTask>();
            foreach (var task in _context.Tasks)
            {
                if (task.UserId == id)
                {
                   
                        userTasks.Add(task);
                    

                }
            }
            return Ok(userTasks);
        }


        [HttpGet("TodayByUser/{id}")]
        public async Task<ActionResult<IEnumerable<UserTask>>> GetUserTodayTaskByUser(int id)
        {
            if (_context.Tasks == null)
            {
                return NotFound();
            }
            List<UserTask> userTasks = new List<UserTask>();
            foreach(var task in _context.Tasks)
            {
                if(task.UserId == id)
                {
                    if(task.DueDate.Date == DateTime.Now.Date)
                    {
                        userTasks.Add(task);
                    }

                }
            }
            return Ok(userTasks);
        }


        [HttpPost]
        [Route("ByDay")]
        public async Task<ActionResult<IEnumerable<UserTask>>> GetUserTaskByDay(TaskGetByDay byDay)
        {
            if (_context.Tasks == null)
            {
                return NotFound();
            }
            List<UserTask> userTasks = new List<UserTask>();
            foreach (var task in _context.Tasks)
            {
                if(task.UserId == byDay.UserId)
                if (task.DueDate.Date == byDay.DateTime.Date)
                {
                   
                      userTasks.Add(task);
                    

                }
            }
            return Ok(userTasks);
        }


        // PUT: api/UserTasks/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutUserTask(int id, TaskPutRequest userTask)
        {
            if (id != userTask.Id)
            {
                return BadRequest();
            }
            var existingTask = await _context.Tasks.FindAsync(id);
            if (existingTask == null) { 
                return NotFound(id);
            
            }
            existingTask.Name = userTask.Name;
            if (userTask.EventId == 0)
            {
                existingTask.EventId = null;
            }
            else
            {
                existingTask.EventId = userTask.EventId;
            }
            existingTask.Description = userTask.Description;
            existingTask.DueDate = userTask.DueDate;
            existingTask.Status = userTask.Status;
            existingTask.Priority = userTask.Priority;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UserTaskExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }



            return NoContent();
        }

        // POST: api/UserTasks
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<UserTask>> PostUserTask(TaskAddRequest userTask)
        {
            if (_context.Tasks == null)
            {
                return Problem("Entity set 'TaskManagementContext.Tasks'  is null.");
            }
            if (userTask.DueDate.Month < DateTime.Now.Month)
            {
                return BadRequest("Invalid date");
            }

            UserTask newTask = new UserTask();
            newTask.DueDate = userTask.DueDate; 
            newTask.UserId = userTask.UserId;
            newTask.Name = userTask.Name;
            newTask.Description = userTask.Description;
            newTask.Status = userTask.Status;
            if (userTask.EventId == 0)
            {
                newTask.EventId = null;
            }
            else
            {
                newTask.EventId = userTask.EventId;
            }
            newTask.Priority = userTask.Priority;


            _context.Tasks.Add(newTask);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetUserTask", new { id = newTask.Id }, newTask);
        }

        // DELETE: api/UserTasks/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUserTask(int id)
        {
            if (_context.Tasks == null)
            {
                return NotFound();
            }
            var userTask = await _context.Tasks.FindAsync(id);
            if (userTask == null)
            {
                return NotFound();
            }

            _context.Tasks.Remove(userTask);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool UserTaskExists(int id)
        {
            return (_context.Tasks?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}

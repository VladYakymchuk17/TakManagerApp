﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using WebApiTaskManagement.Models;

namespace WebApiTaskManagement.Data
{
    public class TaskManagementContext : DbContext
    {
        private readonly IConfiguration configuration;
        public DbSet<User> Users { get; set; }
        public DbSet<UserTask> Tasks { get; set; }
        public DbSet<Event> Events { get; set; }

        public TaskManagementContext(IConfiguration _configuration)
        {
            configuration = _configuration;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseNpgsql(configuration.GetConnectionString("WebApiPostgres"));
        }



    }
}

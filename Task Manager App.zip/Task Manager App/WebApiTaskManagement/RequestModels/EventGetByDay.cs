﻿namespace WebApiTaskManagement.RequestModels
{
    public class EventGetByDay
    {
        public DateTime DateTime { get; set; }
        public int UserId { get; set; }
    }
}

﻿namespace WebApiTaskManagement.RequestModels
{
    public class GetEventMonth
    {
        public int UserId { get; set; }
        public DateTime StartDateTime { get; set; }
        public DateTime EndDateTime { get; set; }
    }
}

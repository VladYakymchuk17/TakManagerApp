﻿namespace WebApiTaskManagement.RequestModels
{
    public class TaskGetByDay
    {
        public DateTime DateTime { get; set; }
        public int UserId { get; set; }
    }
}

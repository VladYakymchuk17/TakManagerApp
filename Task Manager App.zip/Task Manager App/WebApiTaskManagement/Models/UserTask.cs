﻿namespace WebApiTaskManagement.Models
{
    public class UserTask
    {
        public int Id { get; set; }
        public int UserId { get; set; }

        public int? EventId { get; set; }
        public string Name { get; set; }
        public DateTime DueDate { get; set; }
        public int Priority {  get; set; }
        public string Description { get; set; }
        public string Status { get; set; }
        public User AssignedUser { get; set; }


    }
}
